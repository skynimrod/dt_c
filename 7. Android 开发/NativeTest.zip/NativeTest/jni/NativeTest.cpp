#include <jni.h>
#include <android/native_window.h>
#include <android_native_app_glue.h>
#include <android/log.h>
#include <stdio.h>

static void onAppCmd(struct android_app* app, int32_t cmd) {
    switch (cmd) {
        case APP_CMD_SAVE_STATE:
            // The system has asked us to save our current state.  Do so.
        __android_log_print(ANDROID_LOG_DEBUG, "fuke", "engine_handle_cmd APP_CMD_SAVE_STATE");
            break;
        case APP_CMD_INIT_WINDOW:
            // The window is being shown, get it ready.
        __android_log_print(ANDROID_LOG_DEBUG, "fuke", "engine_handle_cmd APP_CMD_INIT_WINDOW");
            break;
        case APP_CMD_TERM_WINDOW:
        __android_log_print(ANDROID_LOG_DEBUG, "fuke", "engine_handle_cmd APP_CMD_TERM_WINDOW");
            break;
        case APP_CMD_GAINED_FOCUS:
            // When our app gains focus, we start monitoring the accelerometer.
        __android_log_print(ANDROID_LOG_DEBUG, "fuke", "engine_handle_cmd APP_CMD_GAINED_FOCUS");
            break;
        case APP_CMD_LOST_FOCUS:
            // When our app loses focus, we stop monitoring the accelerometer.
            // This is to avoid consuming battery while not being used.
        __android_log_print(ANDROID_LOG_DEBUG, "fuke", "engine_handle_cmd APP_CMD_LOST_FOCUS");
            break;
    }
}

static int32_t onInputEvent(struct android_app* app, AInputEvent* event) {
    if (AInputEvent_getType(event) == AINPUT_EVENT_TYPE_MOTION) {
        int nNum = AMotionEvent_getPointerCount(event);
        char szTrace[1024] = {0};
        sprintf (szTrace, "engine_handle_input num=[%d]", nNum);
        for (int nIdx = 0; nIdx < nNum; nIdx++)
        {
        int nX = AMotionEvent_getX(event, 0);
        int nY = AMotionEvent_getY(event, 0);
        sprintf (strrchr(szTrace, 0), " (%d %d)", nX, nY);
        }
        __android_log_print(ANDROID_LOG_DEBUG, "colorspace",
        "%s", szTrace);
        if (AKeyEvent_getAction(event) != AKEY_EVENT_ACTION_UP)
        return 1;
        ANativeWindow_Buffer	nativeWindow = {0};
        int nRet = ANativeWindow_lock(app->pendingWindow, &nativeWindow, NULL);
        int nArea = nativeWindow.width * nativeWindow.height;
        unsigned long*	pdwScreen = (unsigned long*)nativeWindow.bits;
        static int s_nClr = 0;
        unsigned long pdwClr[] = {
        0x00000000, 0x000000ff, 0x0000ffff, 0x0000ff00,
        0x00ffff00, 0x00ff0000, 0x00ff00ff, 0x00ffffff};
        s_nClr ++;
        if (s_nClr > sizeof(pdwClr) / sizeof(unsigned long))
        s_nClr = 0;
        for (int nIdx = 0; nIdx < nArea; nIdx++)
        {
        pdwScreen[nIdx] = pdwClr[s_nClr];
        }
        ANativeWindow_unlockAndPost(app->pendingWindow);
        return 1;
    }
    return 0;
}

void android_main(struct android_app* app) {
    // Make sure glue isn't stripped.
    app_dummy();
    app->onAppCmd = onAppCmd;
    app->onInputEvent = onInputEvent;
    while (1) {
        int ident;
        int events;
        struct android_poll_source* source;
        while ((ident=ALooper_pollAll(-1, NULL, &events,
                (void**)&source)) >= 0) {
            // Process this event.
            if (source != NULL) {
                source->process(app, source);
            }
            // Check if we are exiting.
            if (app->destroyRequested != 0) {
                return;
            }
        }
    }
}
